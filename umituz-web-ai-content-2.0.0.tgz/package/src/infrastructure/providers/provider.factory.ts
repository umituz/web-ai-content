/**
 * Provider Factory
 * Manages AI provider registration, selection, and fallback logic
 */

import type {
  ProviderConfig,
  ProviderHealth,
  ProviderType,
  TextGenerationRequest,
  ImageGenerationRequest,
  VideoGenerationRequest,
  ImageToVideoRequest,
  VideoToVideoRequest,
  GeneratedContent,
} from '../../domain/config/ProviderConfig';

// Re-export types for convenience
export type { ProviderConfig, ProviderHealth, ProviderType };
import { ProviderUnavailableError } from './base.provider';
import type { IAIProvider } from './base.provider';

/**
 * Provider Factory
 * Manages multiple AI providers with automatic fallback
 */
export class ProviderFactory {
  private providers: Map<string, IAIProvider> = new Map();
  private config: ProviderConfig;
  private healthStatus: Map<string, ProviderHealth> = new Map();

  constructor(config: ProviderConfig) {
    this.config = config;
  }

  /**
   * Register a provider
   */
  register(provider: IAIProvider): void {
    this.providers.set(provider.id, provider);
    this.healthStatus.set(provider.id, 'healthy');
  }

  /**
   * Get a provider by ID
   */
  getProvider(id: string): IAIProvider | undefined {
    return this.providers.get(id);
  }

  /**
   * Get all registered providers
   */
  getAllProviders(): IAIProvider[] {
    return Array.from(this.providers.values());
  }

  /**
   * Get providers by type
   */
  getProvidersByType(type: ProviderType): IAIProvider[] {
    return this.getAllProviders().filter(
      provider => provider.type === type || provider.type === 'multimodal'
    );
  }

  /**
   * Get the best available provider for a given type
   * Follows priority order with automatic fallback
   */
  getProviderForType(type: ProviderType): IAIProvider {
    const providers = this.getProvidersByType(type);

    if (providers.length === 0) {
      throw new ProviderUnavailableError(`No provider available for type: ${type}`);
    }

    // Try providers in priority order
    for (const providerId of this.config.priority) {
      const provider = providers.find(p => p.id === providerId);
      if (provider && this.isProviderHealthy(provider.id)) {
        return provider;
      }
    }

    // Fallback to first healthy provider
    for (const provider of providers) {
      if (this.isProviderHealthy(provider.id)) {
        return provider;
      }
    }

    // All providers exhausted/unavailable
    throw new ProviderUnavailableError(`All providers unavailable for type: ${type}`);
  }

  /**
   * Get text provider
   */
  getTextProvider(): IAIProvider {
    return this.getProviderForType('text');
  }

  /**
   * Get image provider
   */
  getImageProvider(): IAIProvider {
    return this.getProviderForType('image');
  }

  /**
   * Get video provider
   */
  getVideoProvider(): IAIProvider {
    return this.getProviderForType('video');
  }

  /**
   * Check if a provider is healthy
   */
  async checkProviderHealth(providerId: string): Promise<ProviderHealth> {
    const provider = this.providers.get(providerId);
    if (!provider) {
      return 'unavailable';
    }

    try {
      const health = await provider.healthCheck();
      this.healthStatus.set(providerId, health);
      return health;
    } catch {
      this.healthStatus.set(providerId, 'unavailable');
      return 'unavailable';
    }
  }

  /**
   * Get health status of a provider (cached)
   */
  isProviderHealthy(providerId: string): boolean {
    const status = this.healthStatus.get(providerId);
    return status === 'healthy' || status === 'degraded';
  }

  /**
   * Refresh health status of all providers
   */
  async refreshAllHealth(): Promise<void> {
    const checks = Array.from(this.providers.keys()).map(id =>
      this.checkProviderHealth(id)
    );
    await Promise.all(checks);
  }

  /**
   * Execute a request with automatic fallback
   */
  async executeWithFallback<T>(
    requestType: ProviderType,
    fn: (provider: IAIProvider) => Promise<T>
  ): Promise<T> {
    const providers = this.getProvidersByType(requestType);

    if (providers.length === 0) {
      throw new ProviderUnavailableError(`No provider available for type: ${requestType}`);
    }

    // Try in priority order
    for (const providerId of this.config.priority) {
      const provider = providers.find(p => p.id === providerId);
      if (!provider || !this.isProviderHealthy(provider.id)) {
        continue;
      }

      try {
        return await fn(provider);
      } catch (error) {
        // Mark as degraded and try next provider
        this.healthStatus.set(provider.id, 'degraded');

        if (!this.config.fallbackEnabled) {
          throw error;
        }
        // Continue to next provider
      }
    }

    // Try remaining providers not in priority list
    for (const provider of providers) {
      if (this.config.priority.includes(provider.id)) {
        continue; // Already tried
      }

      if (!this.isProviderHealthy(provider.id)) {
        continue;
      }

      try {
        return await fn(provider);
      } catch (error) {
        this.healthStatus.set(provider.id, 'degraded');
        if (!this.config.fallbackEnabled) {
          throw error;
        }
      }
    }

    throw new ProviderUnavailableError(`All providers failed for type: ${requestType}`);
  }

  /**
   * Generate text with automatic fallback
   */
  async generateText(request: TextGenerationRequest): Promise<GeneratedContent> {
    return this.executeWithFallback('text', provider => provider.generateText(request));
  }

  /**
   * Generate image with automatic fallback
   */
  async generateImage(request: ImageGenerationRequest): Promise<GeneratedContent> {
    return this.executeWithFallback('image', provider => provider.generateImage(request));
  }

  /**
   * Generate video with automatic fallback
   */
  async generateVideo(request: VideoGenerationRequest): Promise<GeneratedContent> {
    return this.executeWithFallback('video', provider => provider.generateVideo(request));
  }

  /**
   * Convert image to video with automatic fallback
   */
  async imageToVideo(request: ImageToVideoRequest): Promise<GeneratedContent> {
    return this.executeWithFallback('video', provider => provider.imageToVideo(request));
  }

  /**
   * Transform video with automatic fallback
   */
  async videoToVideo(request: VideoToVideoRequest): Promise<GeneratedContent> {
    return this.executeWithFallback('video', provider => provider.videoToVideo(request));
  }
}

/**
 * Create a provider factory from configuration
 */
export function createProviderFactory(config: ProviderConfig): ProviderFactory {
  return new ProviderFactory(config);
}
