/**
 * useContentWizard Hook
 * React hook for the content generation wizard
 */

import { useState, useCallback, useMemo } from 'react';
import type { ContentWizardStep, ContentWizardData } from '../../application/flows/content.wizard';

/**
 * useContentWizard hook options
 */
export interface UseContentWizardOptions {
  initialStep?: ContentWizardStep;
  onStepChange?: (from: ContentWizardStep, to: ContentWizardStep) => void;
  onComplete?: (data: ContentWizardData) => void;
}

/**
 * useContentWizard hook return
 */
export interface UseContentWizardReturn {
  // State
  currentStep: ContentWizardStep;
  steps: Array<{ id: string; label: string; icon?: string; description?: string }>;
  wizardData: ContentWizardData;
  isProcessing: boolean;
  progress: number;

  // Navigation
  next: () => void;
  back: () => void;
  skip: () => void;
  goTo: (step: ContentWizardStep) => void;

  // Data management
  updateData: (updates: Partial<ContentWizardData>) => void;
  setData: (data: ContentWizardData) => void;

  // State management
  setIsProcessing: (processing: boolean) => void;

  // Validation
  canGoNext: () => boolean;
  canGoBack: () => boolean;
  canSkip: () => boolean;

  // Utilities
  isComplete: () => boolean;
  reset: () => void;
}

/**
 * Content wizard steps
 */
const WIZARD_STEPS = [
  { id: 'select-type', label: 'Select Type', icon: 'Layers', description: 'Choose the type of content' },
  { id: 'input-topic', label: 'Topic', icon: 'Lightbulb', description: 'Enter your topic or idea' },
  { id: 'configure', label: 'Configure', icon: 'Settings', description: 'Set tone, audience, platform' },
  { id: 'advanced', label: 'Advanced', icon: 'Sliders', description: 'Additional options' },
  { id: 'preview', label: 'Preview', icon: 'Eye', description: 'Review settings' },
  { id: 'generating', label: 'Generating', icon: 'Sparkles', description: 'AI is generating' },
  { id: 'results', label: 'Results', icon: 'CheckCircle', description: 'Content is ready' },
];

/**
 * useContentWizard hook
 */
export function useContentWizard(options: UseContentWizardOptions = {}): UseContentWizardReturn {
  const [currentStep, setCurrentStep] = useState<ContentWizardStep>(
    options.initialStep || 'select-type'
  );
  const [wizardData, setWizardData] = useState<ContentWizardData>({});
  const [isProcessing, setIsProcessing] = useState(false);

  const steps = useMemo(() => WIZARD_STEPS, []);

  const calculateProgress = useCallback((): number => {
    const currentIndex = steps.findIndex(s => s.id === currentStep);
    return Math.round((currentIndex / (steps.length - 1)) * 100);
  }, [currentStep, steps]);

  const next = useCallback(() => {
    const currentIndex = steps.findIndex(s => s.id === currentStep);
    if (currentIndex < steps.length - 1) {
      const from = currentStep;
      const to = steps[currentIndex + 1].id as ContentWizardStep;
      setCurrentStep(to);
      options.onStepChange?.(from, to);
    }
  }, [currentStep, steps, options]);

  const back = useCallback(() => {
    const currentIndex = steps.findIndex(s => s.id === currentStep);
    if (currentIndex > 0) {
      const from = currentStep;
      const to = steps[currentIndex - 1].id as ContentWizardStep;
      setCurrentStep(to);
      options.onStepChange?.(from, to);
    }
  }, [currentStep, steps, options]);

  const skip = useCallback(() => {
    next(); // Skip is same as next for optional steps
  }, [next]);

  const goTo = useCallback((step: ContentWizardStep) => {
    const from = currentStep;
    setCurrentStep(step);
    options.onStepChange?.(from, step);
  }, [currentStep, options]);

  const updateData = useCallback((updates: Partial<ContentWizardData>) => {
    setWizardData(prev => ({ ...prev, ...updates }));
  }, []);

  const setData = useCallback((data: ContentWizardData) => {
    setWizardData(data);
  }, []);

  const canGoNext = useCallback(() => {
    const currentIndex = steps.findIndex(s => s.id === currentStep);
    return currentIndex < steps.length - 1;
  }, [currentStep, steps]);

  const canGoBack = useCallback(() => {
    const currentIndex = steps.findIndex(s => s.id === currentStep);
    return currentIndex > 0;
  }, [currentStep, steps]);

  const canSkip = useCallback(() => {
    const step = steps.find(s => s.id === currentStep);
    return step?.id === 'advanced'; // Only advanced step is optional
  }, [currentStep, steps]);

  const isComplete = useCallback(() => {
    return currentStep === 'results';
  }, [currentStep]);

  const reset = useCallback(() => {
    setCurrentStep(options.initialStep || 'select-type');
    setWizardData({});
    setIsProcessing(false);
  }, [options.initialStep]);

  return {
    currentStep,
    steps,
    wizardData,
    isProcessing,
    progress: calculateProgress(),
    next,
    back,
    skip,
    goTo,
    updateData,
    setData,
    setIsProcessing,
    canGoNext,
    canGoBack,
    canSkip,
    isComplete,
    reset,
  };
}
